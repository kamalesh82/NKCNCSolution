(function(){
  var CATS=[
    {id:'mills',name:'Ball nose & end mills'},
    {id:'taper',name:'Taper ball nose'},
    {id:'special',name:'Engraving & special bits'},
    {id:'holders',name:'Collets, nuts & brushes'},
    {id:'spindles',name:'Spindles, VFD & bearings'},
    {id:'controllers',name:'Controllers'},
    {id:'motion',name:'Servo, stepper & motion'},
    {id:'electrical',name:'Electrical, cooling & dust'}
  ];
  var TOOL_CATS={mills:1,taper:1,special:1,holders:1};

  /* "label price|label price": the price is the last token */
  function V(s){return s.split('|').map(function(x){x=x.trim();var i=x.lastIndexOf(' ');return [x.slice(0,i).replace(/\*/g,'×').replace(/ SHANK/i,' shank'),+x.slice(i+1)]})}
  function taper(sizes,tail,price){return sizes.map(function(s){return [s+'/'+tail,price]})}
  var TS=['0.5','1','1.5','2','3','4','5'];
  var T2=[];
  taper(TS,'6×25×50',590).forEach(function(v){T2.push(v)});
  taper(TS,'6×40×80',1000).forEach(function(v){T2.push(v)});
  taper(['1','1.5','2','3','4','5','6'],'8×50×100',2200).forEach(function(v){T2.push(v)});
  taper(['2','3','4','5','6'],'10×80×120',4500).forEach(function(v){T2.push(v)});
  taper(['1','1.5','2','3','4','5','6'],'10×100×150',5200).forEach(function(v){T2.push(v)});

  var F=[
    {id:'m1',cat:'mills',name:'2F Ball Nose & End Mill',fin:'Uncoated',v:V('3*22*50 280|4*22*50 380|5*22*50 450|6*22*50 470|8*33*60 1200|5*33*60 550|6*33*60 650|5*40*75 650|6*40*75 850|8*40*75 1600|6*50*100 980|8*50*100 1950')},
    {id:'m2',cat:'mills',name:'2F Ball Nose & End Mill',fin:'Copper coated',v:V('3*22*50 290|4*22*50 390|5*22*50 460|6*22*50 480|8*33*60 1210|5*33*60 600|6*33*60 660|5*40*75 660|6*40*75 860|8*40*75 1610|6*50*100 1000|8*50*100 2000|10*40*80 2750|12*40*80 4100|10*50*100 3300|12*50*100 4500|8*80*120 2200|10*80*120 3700|10*100*150 4400|12*100*150 6500')},
    {id:'m3',cat:'mills',name:'4F Ball Nose',fin:'Uncoated',v:V('4*22*50 370|5*22*50 470|6*22*50 490|8*33*60 1200')},
    {id:'m4',cat:'mills',name:'4F Ball Nose & End Mill',fin:'Copper coated',v:V('4*22*50 370|5*22*50 490|6*22*50 500|8*33*60 1200|6*40*75 950|8*50*100 1950')},
    {id:'m5',cat:'mills',name:'2F Straight End Mill',fin:'Uncoated, polished',v:V('3*22*50 290|4*25*50 390|5*25*50 490|6*25*50 510|5*33*60 630|6*33*60 720|6*40*75 920|8*33*60 1200|8*40*75 1550|8*50*100 1950|10*40*80 2700|10*50*100 3300')},
    {id:'m6',cat:'mills',name:'Single Flute Up-cut End Mill',fin:'Uncoated, polished',v:V('2*10*50*SH3 260|3*22*50 260|4*25*50 390|5*25*50 480|6*25*50 500|5*33*60 620|6*33*60 710|6*40*75 920|8*33*60 1200|8*40*75 1550|8*50*100 1950|10*40*80 2800')},
    {id:'m7',cat:'mills',name:'2F Ball Nose',fin:'DLC coated',v:V('3*22*50 300|4*22*50 390|5*22*50 660|6*22*50 700|8*33*60 1500')},
    {id:'m8',cat:'mills',name:'2F Straight End Mill',fin:'DLC coated',v:V('3*22*50 320|4*25*50 420|5*25*50 530|6*25*50 550|6*33*60 900|8*33*60 1200')},
    {id:'m9',cat:'mills',name:'Single Flute Up-cut End Mill',fin:'DLC coated',v:V('3*22*50 350|4*25*50 420|5*25*50 540|6*25*50 560|6*33*60 780|8*33*60 1200')},

    {id:'t1',cat:'taper',name:'2F Taper Ball Nose',fin:'Uncoated',v:taper(TS,'6×25×50',570)},
    {id:'t2',cat:'taper',name:'2F Taper Ball Nose',fin:'Copper coated',v:T2},
    {id:'t3',cat:'taper',name:'4F Taper Ball Nose',fin:'Uncoated',v:taper(['3','4','5'],'6×25×50',600)},
    {id:'t4',cat:'taper',name:'4F Taper Ball Nose',fin:'Copper coated',v:taper(['3','4','5'],'6×25×50',620)},

    {id:'s1',cat:'special',name:'Jewellery Engraving Bit',fin:'Sharp V-point',v:V('D0.1*17*3*50L 300|D0.1*20*4*50L 400|D0.1*20*5*50L 700|D0.1*20*6*50L 750|D0.2*32*6*60L 900')},
    {id:'s2',cat:'special',name:'Corn Teeth End Mill',v:V('4*25*50 460|5*25*50 560|6*25*50 580|8*33*60 1200')},
    {id:'s3',cat:'special',name:'TCT 2F Straight End Mill',v:V('2*10*8 SHANK 280|3*18*8 SHANK 400|4*22*8 SHANK 450|5*25*12 SHANK 550|6*25*12 SHANK 570')},
    {id:'s4',cat:'special',name:'TCT 3F Straight Roughing End Mill',v:V('4*22*8 SHANK 460|5*25*12 SHANK 560|6*25*12 SHANK 580|6*35*12 SHANK 850|8*25*12 SHANK 850|8*35*12 SHANK 1000')},

    {id:'h1',cat:'holders',name:'ER Collet',v:[['ER20',220],['ER25',220],['ER32',250]]},
    {id:'h2',cat:'holders',name:'ER Chuck Nut',v:[['ER20 A',280],['ER25 UM',300],['ER32 UM',350]]},
    {id:'h3',cat:'holders',name:'4 inch Wire Brush',v:[['Makita brush',290],['Nylon brush',170]]},

    {id:'p1',cat:'spindles',name:'Air Cooled Spindle',v:[['ER20 · 3.5 kW 220V',17500],['ER25 · 3.5 kW 220V',20500],['ER32 · 4.5 kW 380V',23500],['ER32 · 6 kW 380V',24500]]},
    {id:'p2',cat:'spindles',name:'Water Cooled Spindle',v:[['2.2 kW 220V · 100 mm dia',15500],['3.2 kW 220V/380V · 100 mm dia',21000],['4.5 kW 380V · 125 mm dia',26000],['5.5 kW 380V · 125 mm dia',34500],['6.5 kW 380V · 125 mm dia',37000]]},
    {id:'p3',cat:'spindles',name:'Spindle VFD',fin:'Variable frequency drive',v:[['3.7 kW 220V',11500],['4 kW 380V',12500],['5.5 kW 380V',14500],['7.5 kW 380V',16500]]},
    {id:'p4',cat:'spindles',name:'Spindle Bearings',fin:'Steel, price per pair',v:[['H7002C-2RZDTP4',1900],['H7003C-2RZDTP4',2000],['H7005C-2RZDTP4',2600],['H7007C-2RZDTP4',3600],['H7008C-2RZDTP4',4150]]},
    {id:'p5',cat:'spindles',name:'Water Spindle Clamp',v:[['100 mm',1800],['125 mm',2200]]},

    {id:'c1',cat:'controllers',name:'Rich Auto A11E Controller',v:[['Complete set',24000],['Remote only',16500],['4 m cable',3500],['Rich Auto card',4500],['LCD display screen',2800],['Keypad set',1750],['Keypad stickers',850]]},
    {id:'c2',cat:'controllers',name:'NK 105 Controller',v:[['G2 set',34500],['G3 set',36500],['G2 keypad stickers',1200],['G3 keypad stickers',1500]]},

    {id:'d1',cat:'motion',name:'Yako MS-S3 Easy Servo',v:[['Full set: motor, drive, 10 m encoder cable',15500],['Motor only',7300],['Drive only',7000],['10 m encoder cable',2000]]},
    {id:'d2',cat:'motion',name:'Leadshine Easy Servo',v:[['Full set: motor, drive, 10 m encoder cable',15500],['Drive only',7500],['Motor only',7500],['10 m cable',2000]]},
    {id:'d3',cat:'motion',name:'Stepper Motor',v:[['86 frame · 14 mm shaft',4000]]},
    {id:'d4',cat:'motion',name:'Stepper Drive',v:[['Leadshine DMA860H',4750],['Microstep DMA860H',4000],['Yako 2D68-MH',4200],['Yako YKA-2811MA',10500]]},
    {id:'d5',cat:'motion',name:'Helical Gearbox Set',fin:'Gearbox, belt and pulley',v:[['Full set',2800]]},
    {id:'d6',cat:'motion',name:'5M Timing Belt',v:[['300-5M',280],['310-5M',280],['320-5M',280],['330-5M',280],['340-5M',280],['350-5M',280],['550-5M',280]]},
    {id:'d7',cat:'motion',name:'Timing Pulley',fin:'14 mm bore',v:[['18 teeth',280],['20 teeth',300]]},
    {id:'d8',cat:'motion',name:'Linear Guideway Block',v:[['HGH20CA',750],['HGH25CA',850]]},
    {id:'d9',cat:'motion',name:'Plastic Drag Chain',fin:'Price per metre',v:[['25 × 57',800],['35 × 75',1000]]},

    {id:'e1',cat:'electrical',name:'Proximity Sensor',fin:'NPN, normally open',v:[['Roko SN04-N',300],['Omron TL-Q5MC1-Z',400]]},
    {id:'e2',cat:'electrical',name:'Push Button Switch',v:[['Selector switch',250],['Push button',250],['Red stay-put button',250]]},
    {id:'e3',cat:'electrical',name:'AC Contactor & MCB',v:[['CJX2 1810 contactor',1000],['CJX2 2510 contactor',1200],['CHNT NXB-63 C32 MCB',650]]},
    {id:'e4',cat:'electrical',name:'Transformer',v:[['220V in · 70V out',5300],['220V in · 110V out',5800]]},
    {id:'e5',cat:'electrical',name:'SMPS Power Supply',v:[['100 W · 24V · 4.5A',1200]]},
    {id:'e6',cat:'electrical',name:'Submersible Water Pump',v:[['220V 80W · 3.5 m head · 3500 L/h',2000],['220V 100W · 4.5 m head · 4500 L/h',2500]]},
    {id:'e7',cat:'electrical',name:'5 × 8 Water Pipe',v:[['Per metre',40],['Full roll',3000]]},
    {id:'e8',cat:'electrical',name:'Exhaust Fan',v:[['120 × 120 × 38 mm',380]]},
    {id:'e9',cat:'electrical',name:'Dust Hose, PU Flexible',fin:'Transparent, 102 mm diameter',v:[['6.5 metre',3600],['8.5 metre',4700]]},
    {id:'e10',cat:'electrical',name:'Dust Cover Brush',fin:'For CNC dust collector',v:[['70 mm',1700],['80 mm',1800],['100 mm',2000],['120 mm',2200]]},
    {id:'e11',cat:'electrical',name:'Clamping Set',v:[['4 inch clamp set',170],['7 inch clamp set',240],['4 inch patti',85],['4 inch nut bolts',85],['7 inch patti',100],['7 inch nut bolts',120]]}
  ];

  var SVG='<svg viewBox="0 0 96 96" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">';
  var ICON={
    bit:SVG+'<path d="M40 10h16v26H40z"/><path d="M40 36l4 40 4 10 4-10 4-40"/><path d="M42 46l12 6M42 58l12 6"/></svg>',
    holder:SVG+'<circle cx="48" cy="48" r="30"/><circle cx="48" cy="48" r="12"/><path d="M48 18v12M48 66v12M18 48h12M66 48h12"/></svg>',
    spindle:SVG+'<rect x="30" y="12" width="36" height="46" rx="4"/><path d="M38 58v12h20V58M48 70v14"/><path d="M30 28h36M30 42h36"/></svg>',
    ctrl:SVG+'<rect x="16" y="22" width="64" height="52" rx="4"/><rect x="24" y="30" width="26" height="14"/><path d="M58 32h14M58 42h14M26 56h8M42 56h8M58 56h14M26 66h8M42 66h8"/></svg>',
    motion:SVG+'<circle cx="48" cy="48" r="14"/><path d="M48 10v14M48 72v14M10 48h14M72 48h14M21 21l10 10M65 65l10 10M75 21L65 31M31 65L21 75"/></svg>',
    elec:SVG+'<path d="M54 8L24 54h22l-6 34 32-48H50z"/></svg>'
  };
  var CATICON={mills:'bit',taper:'bit',special:'bit',holders:'holder',spindles:'spindle',controllers:'ctrl',motion:'motion',electrical:'elec'};
  var CATNAME={};CATS.forEach(function(c){CATNAME[c.id]=c.name});

  var inr=new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:0});
  function $(id){return document.getElementById(id)}
  function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
  var FBY={};F.forEach(function(f){FBY[f.id]=f});
  function item(key){var p=key.split('~'),f=FBY[p[0]];if(!f)return null;var v=f.v[+p[1]];if(!v)return null;return {f:f,label:v[0],price:v[1]}}

  var cart={}, cat='all', view='cart', lastFocus=null, orderInfo=null;
  try{var raw=localStorage.getItem('nk-cart-v2');if(raw){var o=JSON.parse(raw);Object.keys(o).forEach(function(k){if(item(k)&&o[k]>0)cart[k]=o[k]})}}catch(e){}
  function save(){try{localStorage.setItem('nk-cart-v2',JSON.stringify(cart))}catch(e){}}
  function count(){return Object.keys(cart).reduce(function(n,k){return n+cart[k]},0)}
  function subtotal(){return Object.keys(cart).reduce(function(n,k){return n+cart[k]*item(k).price},0)}
  function hasTools(){return Object.keys(cart).some(function(k){return TOOL_CATS[item(k).f.cat]})}

  /* catalogue */
  function renderChips(){
    var h='<button class="chip" type="button" data-cat="all" aria-pressed="'+(cat==='all')+'">All</button>';
    CATS.forEach(function(c){h+='<button class="chip" type="button" data-cat="'+c.id+'" aria-pressed="'+(cat===c.id)+'">'+esc(c.name)+'</button>'});
    $('chips').innerHTML=h;
  }
  function renderGrid(){
    var q=$('search').value.trim().toLowerCase().replace(/\*/g,'×').replace(/x/g,'×');
    var list=F.filter(function(f){
      if(cat!=='all'&&f.cat!==cat)return false;
      if(!q)return true;
      var hay=(f.name+' '+(f.fin||'')+' '+f.v.map(function(v){return v[0]}).join(' ')).toLowerCase().replace(/x/g,'×');
      return hay.indexOf(q)>-1;
    });
    $('none').hidden=list.length>0;
    $('meta').textContent=list.length+' product'+(list.length===1?'':'s')+(cat==='all'?'':' in '+CATNAME[cat]);
    $('grid').innerHTML=list.map(function(f){
      var multi=f.v.length>1;
      var sel=multi?'<label><span class="label">'+(TOOL_CATS[f.cat]&&f.cat!=='holders'?'Size (mm)':'Variant')+'</span><select class="field vsel" aria-label="Choose variant for '+esc(f.name)+'">'+
        f.v.map(function(v,i){return '<option value="'+i+'">'+esc(v[0])+' · '+inr.format(v[1])+'</option>'}).join('')+'</select></label>'
        :'<div class="one">'+esc(f.v[0][0])+'</div>';
      return '<article class="card" data-f="'+f.id+'"><div class="thumb" aria-hidden="true">'+ICON[CATICON[f.cat]]+'</div><div class="body">'+
        '<span class="label">'+esc(CATNAME[f.cat])+'</span>'+
        '<h3>'+esc(f.name)+'</h3>'+(f.fin?'<div class="fin">'+esc(f.fin)+'</div>':'')+sel+
        '<div class="price"><b class="pv">'+inr.format(f.v[0][1])+'</b><span>'+(multi?f.v.length+' options':'')+'</span></div>'+
        '<button class="btn" type="button" data-add>Add to cart</button></div></article>';
    }).join('');
  }
  $('chips').addEventListener('click',function(e){var b=e.target.closest('[data-cat]');if(!b)return;cat=b.getAttribute('data-cat');renderChips();renderGrid()});
  $('search').addEventListener('input',renderGrid);
  $('grid').addEventListener('change',function(e){
    var s=e.target.closest('.vsel');if(!s)return;
    var card=s.closest('.card'),f=FBY[card.getAttribute('data-f')];
    card.querySelector('.pv').textContent=inr.format(f.v[+s.value][1]);
  });
  $('grid').addEventListener('click',function(e){
    var b=e.target.closest('[data-add]');if(!b)return;
    var card=b.closest('.card'),s=card.querySelector('.vsel');
    var key=card.getAttribute('data-f')+'~'+(s?s.value:0);
    cart[key]=(cart[key]||0)+1;save();updateCount();
    b.textContent='Added ✓';setTimeout(function(){b.textContent='Add to cart'},900);
  });
  function updateCount(){$('cartCount').textContent=count()}

  /* drawer */
  function openDrawer(v){
    lastFocus=document.activeElement;view=v||'cart';renderDrawer();$('layer').hidden=false;
    document.body.style.overflow='hidden';$('closeCart').focus();
  }
  function closeDrawer(){
    $('layer').hidden=true;document.body.style.overflow='';
    if(view==='done'){cart={};save();updateCount();view='cart';orderInfo=null}
    if(lastFocus&&lastFocus.focus)lastFocus.focus();
  }
  $('openCart').addEventListener('click',function(){openDrawer('cart')});
  $('closeCart').addEventListener('click',closeDrawer);
  $('scrim').addEventListener('click',closeDrawer);
  document.addEventListener('keydown',function(e){if(e.key==='Escape'&&!$('layer').hidden)closeDrawer()});

  function totalsHtml(){
    var s=subtotal(),note='';
    if(hasTools()&&s<2000)note='<div class="warnnote">The tool price list asks for a minimum order of ₹2,000. This cart is '+inr.format(2000-s)+' short.</div>';
    return note+'<div class="tot"><div><span>Subtotal</span><span>'+inr.format(s)+'</span></div>'+
      '<div><span>GST and delivery</span><span class="small">Confirmed on order</span></div>'+
      '<div class="grand"><span>Total</span><span>'+inr.format(s)+'</span></div></div>';
  }
  function renderDrawer(){
    var body=$('dBody'),foot=$('dFoot');
    if(view==='cart'){
      $('dTitle').textContent='Your cart';
      var ids=Object.keys(cart);
      if(!ids.length){body.innerHTML='<p class="empty">Your cart is empty. Add a tool or spare part from the catalogue.</p>';foot.innerHTML='<button class="btn ghost wide" type="button" data-close>Continue browsing</button>';return}
      body.innerHTML=ids.map(function(k){var it=item(k),q=cart[k];
        return '<div class="line"><div><b>'+esc(it.f.name)+(it.f.fin?' · '+esc(it.f.fin):'')+'</b><em>'+esc(it.label)+'</em></div><span class="amt">'+inr.format(it.price*q)+'</span>'+
          '<span class="qty"><button type="button" data-dec="'+k+'" aria-label="Decrease quantity">−</button><span aria-live="polite">'+q+'</span><button type="button" data-inc="'+k+'" aria-label="Increase quantity">+</button></span>'+
          '<button class="rm" type="button" data-rm="'+k+'">Remove</button></div>';
      }).join('');
      foot.innerHTML=totalsHtml()+'<button class="btn wide" type="button" data-go="details">Checkout</button>';
    }else if(view==='details'){
      $('dTitle').textContent='Delivery & payment';
      body.innerHTML='<form id="coForm" novalidate style="padding-top:14px">'+
        '<label>Full name<input class="field" id="coName" autocomplete="name"><span class="err" id="coNameErr"></span></label>'+
        '<div class="row"><label>Phone<input class="field" id="coPhone" type="tel" inputmode="tel" autocomplete="tel"><span class="err" id="coPhoneErr"></span></label>'+
        '<label>Email<input class="field" id="coEmail" type="email" autocomplete="email"></label></div>'+
        '<label>Company name (optional)<input class="field" id="coCompany" autocomplete="organization"></label>'+
        '<label>GSTIN (optional)<input class="field" id="coGst" maxlength="15" style="text-transform:uppercase"></label>'+
        '<label>Delivery address<textarea class="field" id="coAddr"></textarea><span class="err" id="coAddrErr"></span></label>'+
        '<div class="row"><label>City<input class="field" id="coCity" autocomplete="address-level2"></label><label>PIN code<input class="field" id="coPin" inputmode="numeric" maxlength="6" autocomplete="postal-code"></label></div>'+
        '<fieldset class="pay" style="border:0;padding:0;margin:0"><legend class="label" style="margin-bottom:8px">Payment</legend>'+
        '<label><input type="radio" name="pay" value="online" checked><span>Pay online<small>UPI, cards and net banking, once a payment provider is connected</small></span></label>'+
        '<label><input type="radio" name="pay" value="invoice"><span>Send me an invoice<small>Bank transfer against a proforma invoice</small></span></label></fieldset>'+
        '</form>';
      foot.innerHTML=totalsHtml()+'<button class="btn wide" type="button" data-place>Place order</button><button class="btn ghost wide" type="button" data-go="cart">Back to cart</button>';
    }else if(view==='done'){
      $('dTitle').textContent='Order received';
      body.innerHTML='<div class="done" style="margin-top:14px"><h3>Thank you, '+esc(orderInfo.name)+'</h3>'+
        '<span class="ref">'+esc(orderInfo.ref)+'</span>'+
        '<p>'+orderInfo.items+' item'+(orderInfo.items===1?'':'s')+', total '+inr.format(orderInfo.total)+' before GST and delivery.</p>'+
        '<p class="small">This is a preview. The order has not been sent to NK CNC Solution and no payment was taken. Online ordering goes live once order delivery and a payment provider are connected.</p></div>';
      foot.innerHTML='<button class="btn wide" type="button" data-close>Close</button>';
    }
  }
  $('layer').addEventListener('click',function(e){
    var t=e.target.closest('button');if(!t)return;
    var k;
    if((k=t.getAttribute('data-inc'))){cart[k]++;save();updateCount();renderDrawer()}
    else if((k=t.getAttribute('data-dec'))){cart[k]--;if(cart[k]<=0)delete cart[k];save();updateCount();renderDrawer()}
    else if((k=t.getAttribute('data-rm'))){delete cart[k];save();updateCount();renderDrawer()}
    else if(t.hasAttribute('data-go')){view=t.getAttribute('data-go');renderDrawer()}
    else if(t.hasAttribute('data-close')){closeDrawer()}
    else if(t.hasAttribute('data-place')){placeOrder()}
  });
  function setErr(id,msg){var el=$(id);if(el)el.textContent=msg||''}
  function validPhone(v){return /^[+\d][\d\s-]{8,14}$/.test(v.trim())}
  function stamp(prefix){var d=new Date();return prefix+'-'+d.getFullYear()+String(d.getMonth()+1).padStart(2,'0')+String(d.getDate()).padStart(2,'0')+'-'+Math.floor(1000+Math.random()*9000)}
  function placeOrder(){
    var ok=true,name=$('coName').value.trim(),phone=$('coPhone').value,addr=$('coAddr').value.trim();
    setErr('coNameErr',name?'':'Enter your name.');if(!name)ok=false;
    setErr('coPhoneErr',validPhone(phone)?'':'Enter a phone number with at least 9 digits.');if(!validPhone(phone))ok=false;
    setErr('coAddrErr',addr?'':'Enter a delivery address.');if(!addr)ok=false;
    if(!ok)return;
    orderInfo={name:name.split(' ')[0],ref:stamp('NK'),items:count(),total:subtotal()};
    view='done';renderDrawer();
  }

  /* machine quote buttons prefill the service form */
  document.getElementById('machines').addEventListener('click',function(e){
    var a=e.target.closest('[data-quote]');if(!a)return;
    $('svcType').value='Machine quote';$('svcMachine').value=a.getAttribute('data-quote');
  });

  /* service form */
  $('svcForm').addEventListener('submit',function(e){
    e.preventDefault();
    var name=$('svcName').value.trim(),phone=$('svcPhone').value,ok=true;
    setErr('svcNameErr',name?'':'Enter your name.');if(!name)ok=false;
    setErr('svcPhoneErr',validPhone(phone)?'':'Enter a phone number with at least 9 digits.');if(!validPhone(phone))ok=false;
    if(!ok)return;
    var when=$('svcDate').value?(' on '+esc($('svcDate').value)):'';
    $('svcForm').hidden=true;
    var box=$('svcDone');box.hidden=false;
    box.innerHTML='<div class="done"><h3>Request logged</h3><span class="ref">'+stamp('SR')+'</span>'+
      '<p>'+esc($('svcType').value)+' · '+esc($('svcMachine').value)+when+'.</p>'+
      '<p class="small">This is a preview. The request has not been sent to NK CNC Solution yet. Call 8553696512 or 8296262344 for anything urgent.</p>'+
      '<button class="btn ghost" type="button" id="svcAgain" style="justify-self:start">Make another request</button></div>';
    $('svcAgain').addEventListener('click',function(){box.hidden=true;$('svcForm').reset();$('svcForm').hidden=false});
  });

  renderChips();renderGrid();updateCount();
})();
